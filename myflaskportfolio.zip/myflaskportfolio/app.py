from flask import Flask, render_template, json

app = Flask(__name__)

@app.route('/')
def index():
    with open("D:\Python development\AsmatullahPortfolioWicky (1)\static\projectss.json") as f:
        projectss = json.load(f)
    with open("D:\Python development\AsmatullahPortfolioWicky (1)\static\certifications.json") as f:
        certifications = json.load(f)
    return render_template("index.html", projects=projectss, certifications=certifications)

if __name__ == '__main__':
    app.run(debug=True)
